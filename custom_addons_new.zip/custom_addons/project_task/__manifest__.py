# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Project_New',
    'version' : '1.0',
    'summary': 'This is a employee module',
    'sequence': 1,
    'description': """Project""",
    'category': 'other',
    'website': 'https://www.ppts.com',
    'depends' : ['base','project','report','purchase'],
    'data': [
        'views/project.xml',
    ],
    'installable': True,
    'application': True,
}
