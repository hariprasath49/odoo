# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
import datetime
from pygments.lexer import _inherit


class Events(models.Model):
    _name = 'event.event'
    
#     choices = ((1, 'Manager'), (2, '(Others'))
    name = fields.Many2one('hr.employee', string="Active")
#      domain="[('department_id','=','Sales')]"
#     name_mode_id = fields('hr.employee',related='name',  invisible=1)  
    name_id =  fields.Char("Name")
    send_to = fields.Char("Send to")
    sale_id = fields.Many2one('sale.order',string="Sale")
#     date = fields.Date.now()
#     admin = fields.Selection(loan)
#     admin = fields.Char(String="Loan Request") 
    
#     partner_id = fields.Many2one('res.partner', string='Customer')
    
    reason = fields.Text("reason")
    amount = fields.Float(string="Amount")
    res_name = fields.Many2one('hr.employee', string="Sale Name", domain="[('department_id','=','Administration')]")
    many_name = fields.Many2many('hr.employee', string="Loan Option")
#     order_line_option = fields.Many2one('sale.order.line.option', string="oder")
    active = fields.Boolean()
    state = fields.Selection([
            ('draft', 'Draft'),
            ('pending', 'Pending'),
            ('confirmed', 'Confirmed'),
            ('rejected', 'Rejected'),
            ], default='draft')
 
    @api.model
    def create(self, vals):
        active = True 
        res = super(Events, self).create(vals)
        print res.name
        print vals['amount']
        print vals.get('name')
        if res.amount > 10000:
            raise UserError(_('Amount is less then 10000'))
        return res
        
       
        
    @api.multi
    def write(self, vals):
        res = super(Events, self).write(vals)
        if self.amount > 10000:
            raise UserError(_('Amount is less then 10000'))
        return res

    @api.multi
    def pending_progressbar(self):
        list = []
        record = self.env['event.child'].create({
                                        'name':self.name.id,
                                        'income':self.amount,
                                        'event_id':self.id,
                                        'res_name':self.res_name.id,
                                            
                                        })
        
        for line in self.many_name:
            # print line
            list.append(line.id)
        record.update({'many_name':list})

        template_id = self.env.ref('parent.mail_create_parent',False)
        template_id.send_mail(self.id, force_send=True)
    
    



     

#     
class EventsList(models.Model):
    _name = 'event.child'
       
    name = fields.Many2one('hr.employee', required=True, string="Name")  
    income = fields.Float(string="Income")
    manager = fields.One2many('event.sub', 's_no', string="Manager")
    reason = fields.Text("Reason")
    res_name = fields.Many2one('hr.employee', string="Canditate Name")
    many_name = fields.Many2many('hr.employee', string="Loan Option")
    
    event_id = fields.Many2one('event.event')
    state = fields.Selection([
            ('draft', 'Draft'),
            ('processing', 'Processing'),
            ('done', 'Done'),
            ('reject', 'Rejected'),
            ], default='draft')

    @api.one
    def approve(self):
        self.event_id.state = 'confirmed'
        
        self.write({
    'state': 'done'
    })
        template_id = self.env.ref('parent.mail_create_parent_approve',False)
        template_id.send_mail(self.id, force_send=True)

    @api.one
    def reject(self):
        if not self.reason:
            raise UserError(_('Please mention the loan reject reason in reason field'))
        else:
            self.event_id.state = 'rejected'
            self.event_id.reason = self.reason
            self.state = 'reject'
            
        template_id = self.env.ref('parent.mail_create_parent_rejected',False)
        template_id.send_mail(self.id, force_send=True)   


class EventSub(models.Model):
    _name = 'event.sub'
    
    date = fields.Date("Date")
    s_no = fields.Integer("S.No", required=True)
    amount = fields.Integer("Amount")
    
class SaleOrder(models.Model):
    _inherit = 'sale.order'
    sale_id = fields.Many2one('sale.order',string="Sale")

    @api.multi
    def send_mail_template(self):
        refund_ids = self.env['sale.order'].search([('partner_id.name', '=', 'hari')])
        print refund_ids.name
        
        ctx = dict(self.env.context or {})
        l = []
        for record in refund_ids:
            print record.partner_id.name
            print record.company_id
             
             
            ctx.update({
                'sale_records': l,
                })
            l.append(record)
             
            print l
 
        ctx.update({
        'sale_records': l,
        })
 
        print ctx['sale_records']
         
        template = self.env.ref('parent.mail_create_parent')
        print template,'nnnnnn'
        template.with_context(ctx).send_mail(self.id) 
        return True 
