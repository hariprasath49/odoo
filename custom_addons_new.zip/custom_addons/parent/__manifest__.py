# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Best Project',
    'version': '1.0',
    'category': 'Task',
    'sequence': 1,
    'summary': 'Task program',
    'description': """""",
    'website': 'https://www.odoo.com/page/employees',
    'depends': ['base', 'hr','sale','mail'],
    'data': [
        'data/mail_template.xml',
        'views/parent.xml',
        'views/student.xml'
            ],
   'installable': True,
   'application': True,
    
}
