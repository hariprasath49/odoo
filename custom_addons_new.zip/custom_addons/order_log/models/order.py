from odoo import models, fields, api, _
from datetime import datetime
from dateutil.relativedelta import relativedelta

class OderLog(models.Model):
    _name = 'order.log'
    partner_id = fields.Char('Customer')
    confirmation_date = fields.Datetime('Customer')
    order_line = fields.One2many('order.log.line','line_pass',string="order")
    
 
class OrderLogLine(models.Model):
    _name = 'order.log.line'
    line_pass = fields.Many2one('order.log') 
    product_id = fields.Many2one('product.product', string='Product')
    product_uom_qty = fields.Float(string='Product Quantity',)
    product_uom = fields.Char(string='Unit')
    sub_total=fields.Float(string='Sub Total')
    price_unit=fields.Float(string='Price')
    
class WizardContract(models.TransientModel):
    _name = 'order.wizard'
    customer_ids=fields.Many2one('res.partner',string='Customer Name' )
    datefrom = fields.Date(string="Date From")
    dateto = fields.Date(string="Date To")
    current_date= fields.datetime.now() 
    
    @api.depends('customer_ids','datefrom','dateto')
    def validate(self):
        search_id = self.env['sale.order'].search([('partner_id','=', self.customer_ids.id),('date_order', '>=', self.datefrom), ('date_order', '<=', self.dateto)])
        
        for line in search_id:
            rec_sale_line = self.env['sale.order.line'].search([('order_id','=', line.id),('order_partner_id','=', self.customer_ids.id)])
            lines = []
            for line in rec_sale_line:
                    lines.append((0, 0, {
                    'product_id':line.product_id.id,
                    'product_uom_qty':line.product_uom_qty,
                    'product_uom':line.product_uom,
                    'price_unit':line.price_unit,
                    'sub_total':line.price_subtotal,
                    }))
            contract_id = self.env['order.log'].create({
                    'partner_id': self.customer_ids.name,
                    'confirmation_date': fields.Datetime.now(),
                    'order_line':lines,
                    })
            
            
    @api.depends('customer_ids','datefrom','dateto')
    def print_report(self):
        print 'gghhhhhhhhhhhhhhhhhhhhhhhuuuu'
        search_id = self.env['sale.order'].search([('partner_id','=', self.customer_ids.id),('date_order', '>=', self.datefrom), ('date_order', '<=', self.dateto)])
        print search_id
        
        lst = []
        for loop in search_id:
            lst.append(str(loop.partner_id.name))
            lst.append(str(self.datefrom))
            lst.append(str(self.current_date))
            
        lines=[]
        
        if self.current_date:
            current_date= str(self.current_date)
            total=0
            
            lines=[]
            rec_sale_line = self.env['sale.order.line'].search([('order_id','=', loop.id),('order_partner_id','=', self.customer_ids.id)])
            for line in rec_sale_line:
                dict_lines = {'product_id':line.product_id.id,
                              'product_uom_qty':line.product_uom_qty,
                              'price_unit':line.price_unit,
                              'sub_total':line.price_subtotal
                    }
                lines.append(dict_lines)
                
        partner_id=lst[0]
        print 'partner name' 
        print partner_id  
        data = {
                    'partner_id': partner_id,
                    'confirmation_date': fields.Datetime.now(),
                    'lst':lst,
                    'lines':lines,
                    }
            
            
#             print self.customer_ids.name
        print line.product_id.name
        print 'athaaa'
        print line
        print type(lst)
            
#         for loop in search_id:
#             lst.append(str(loop.partner_id.name))
            
        print lst, 'testtttt'
#         data = {
#             'lst':lst}
        
        return self.env['report'].get_action([],'order_log.report_template_demo',data=data) 
    
class DemoReport(models.AbstractModel):
    _name = 'report.order_log.report_template_demo'
    
    
    @api.model
    def render_html(self, docids, data):
        
        print data,docids,'test'
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('order_log.report_template_demo')
        lst = []
        lines=[]
        for loop in data['lst']:
            lst.append(str(loop))
        for line in data['lines']:
            lines
            lines.append(str(line))
            
        partner_id=data['partner_id']
        docs = {
            
                'lst':lst,
                'partner_id':partner_id,
                'line':line,
                'data':data,
            }
        print docs,'docs'
        docargs = {
            'doc_ids': docids,
            'doc_model': report.model,
            'docs': docs,
        }
        return report_obj.render('order_log.report_template_demo', docargs)
       