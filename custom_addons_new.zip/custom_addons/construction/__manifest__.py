# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Construction',
    'version' : '1.0',
    'summary': 'Construction Budget Main',
    'sequence': 1,
    'description': """Construction""",
    'category': 'other',
    'website': 'https://www.ppts.com',
    'depends' : ['base','sale','report','hr','purchase'],
    'data': [
        'views/project_task.xml',
        'views/product_product.xml',
        'views/purchase_order.xml',
        'data/report_template_project.xml',
        'data/report_template_purchase.xml'
    ],
    'installable': True,
    'application': True,
}
