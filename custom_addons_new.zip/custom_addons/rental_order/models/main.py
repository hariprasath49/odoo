from odoo import models, fields, api, _
from datetime import datetime
from dateutil.relativedelta import relativedelta

class RentalOrder(models.Model):
    _name = 'rental.order'
    
    partner_id = fields.Char('Customer')
    type_sale = fields.Selection([ ('rental', 'Rental'),('normal', 'Normal'),],'Type', default='normal')
    return_date = fields.Date(string="Return Date")
    date_order = fields.Date(string="Date Order")
    
class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    type_sale = fields.Selection([ ('rental', 'Rental'),('normal', 'Normal'),('none', 'None')],'Type',default='none')
    
    @api.multi
    def action_confirm(self):
        result = super(SaleOrder, self).action_confirm()
        rec_sale_line = self.env['sale.order.line'].search([('type_sale','=', 'rental')])
        print rec_sale_line
        print self.type_sale
        print self.order_line.return_date
        
#         stock = self.env['stock.picking'].browse('location_id')
#         print stock
#         return_date_stock = self.env['stock.picking'].create({
#                         'return_date':self.order_line.return_date,
#             })
        return result
    
    @api.multi
    @api.depends('type_sale')
    def type_send_mail(self):
        product_id_sale = self.env['sale.order.line'].search([('order_id', '=', self.id)])
        ctx = dict(self.env.context or {})
        list_new = []
        for rec in product_id_sale:
            list_new.append(rec)
        ctx.update({
            'product_record': list_new,
            })    
        if self.type_sale != 'normal':        
            template = self.env.ref('rental_order.saleorder_mail_template_type')
            template.with_context(ctx).send_mail(self.id)
        else:
            return True
#     @api.onchange('type_sale')
#     def _onchange_type_sale(self):
#             rec_sale_line = self.env['sale.order.line'].search([('order_id','=', self.id)])
#             for sale_rec in rec_sale_line:
#                 sale_rec.type_sale = self.type_sale
#                 print 'test',self.type_sale
#                 print sale_rec.type_sale   
    
class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    return_date = fields.Date(string="Return Date",required=False)
    type_sale = fields.Selection([ ('rental', 'Rental'),('normal', 'Normal'),('none', 'None')],'Type',default='none', related='order_id.type_sale')
    return_id = fields.Many2one('sale.order.line','return_ids')
    
class StockPicking(models.Model):
    _inherit = 'stock.picking'
    return_ids = fields.Many2one('sale.order.line','return_id')
    return_date =fields.Date(string="Return Date",related='return_ids.return_date')
