# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Rental Orders',
    'version' : '1.0',
    'summary': 'Rental orders',
    'sequence': 1,
    'description': """Rental orders""",
    'category': 'app',
    'website': 'https://www.ppts.com',
    'depends' : ['base','sale'],
    'data': [
        'data/mail_template.xml',
        'views/rental_order.xml',
    ],
    'installable': True,
    'application': True,
}
