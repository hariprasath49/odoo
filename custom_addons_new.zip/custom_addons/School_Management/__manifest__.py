# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'School Management',
    'version' : '1.0',
    'summary': 'This is a test module',
    'sequence': 1,
    'description': """My Test Module""",
    'category': 'other',
    'website': 'https://www.ppts.com',
    'depends' : ['base', 'hr'],
    'data': [
#         'views/dashboard.xml',
        'views/teacher_profile.xml',
    ],
    'installable': True,
    'application': True,
}
