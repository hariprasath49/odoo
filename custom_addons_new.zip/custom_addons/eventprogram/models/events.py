from odoo import api, fields, models, _


class Events(models.Model):
    _name = 'events.events'
     
    name = fields.Char("Name")    
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('others', 'Others')], String='Status', default='male')
    age = fields.Integer(String="Age")
        
    @api.multi
    @api.depends('gender')
    def _compute_values(self):
        for line in self:
            if line.gender == 'male':
                line.work_hrs = 18 * 8
            elif line.gender == 'female':
                line.work_hrs = 24 * 8
            else:
                line.work_hrs = 25 * 8

    work_hrs = fields.Float("work_hrs" , compute='_compute_values', store=True)

    @api.onchange('gender')
    def onchange_values(self):
        for line in self:
            if line.gender == 'male':
                line.age = 18
            elif line.gender == 'female':
                line.age = 24
            else:
                line.age = 25


class Salary(models.Model):
    _name = 'events1.events'
    _rec_name = "name_id"
      
    name_id = fields.Many2one('events.events', string="Name", required=True)
    salary = fields.Integer("salary")
    state = fields.Selection([('open', 'New'), ('pending', 'Pending') , ('confirm', 'Validated')],
                              string='Status', readonly=True, copy=False, default='open')
    reason = fields.Text("Pending Reason")
#     @api.multi
#     @api.depends('name_id')
#     def onchange_values(self): 
#         for line in self:
#             if line.name_id:
#                 line.salary = line.name_id.work_hrs * 12
    
    @api.multi
    def action_button(self):
        if self.name_id:
            self.salary = self.name_id.work_hrs * 12
        if self.salary < 2000:
            self.state = 'pending'
            self.action_button_call()

    @api.multi
    def action_button_on(self):
        if self.state == 'pending' and self.salary >= 2000:
            self.state = 'confirm'
            
    def action_button_call(self):
        print "yes"
        self.salary = 2000
        
