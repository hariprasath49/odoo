# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Order Log',
    'version': '1',
    'category': 'Sale Order',
    'sequence': 1,
    'summary': 'Extend program',
    'description': """""",
    'website': 'https://www.odoo.com/page/',
    'depends': ['sale','hr'],
    'data': [
        'security/ir.model.access.csv',
        'security/order_log.xml',
        'report/report_template_demo.xml',
        'views/order.xml',
        'views/order_wizard.xml',
        
        
                
            ],
   'installable': True,
   'application': True,
  
}
