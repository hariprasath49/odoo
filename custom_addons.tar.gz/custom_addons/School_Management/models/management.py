from odoo import api, fields, models, _


class TeacherProfile(models.Model):
    _name = 'teacher.profile'
    
    name = fields.Char(string="Name")
    note = fields.Char(string="Name")