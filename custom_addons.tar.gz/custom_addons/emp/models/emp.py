# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import date, datetime
from dateutil.relativedelta import relativedelta


class Emp(models.Model):
    _name = 'emp.emp'
#    
    image = fields.Binary("Image", attachment=True, help="aaaaaga")
    name = fields.Char(string="Name", required=True)
    roll_number = fields.Integer(string="Roll No")
    note = fields.Char(string="Note")
    depart = fields.Char(string="Department")
    
    # personal information
    address = fields.Char(string="Address")
    phone = fields.Integer(string="Mobile")
    email = fields.Char(string="Email")
    alterph = fields.Integer(string="Alternate Mobile")
    dob = fields.Date(string="Date of birth")
    
    # other details
    school = fields.Char(string="School")
    language = fields.Char(string="Language")
    parent_number = fields.Char(string="Parent Mobile")
    local_g = fields.Char(string="Local Gaurd")
    notes = fields.Char(string="Notes")
    
    # academic information
    exp = fields.Integer(string="Expirence")
    field_work = fields.Char(string="Fields Worked")
    ach = fields.Char(string="Achivement")
    cu_salary = fields.Char(string="Current Salary")
    
    address_new = fields.Many2one('stu.emp', string="Address")
    
    mari = fields.Selection([('married', 'Married'), ('unmarried', 'Unmarried')], string="Maritial Status")
    
    # test
    blue = fields.Boolean('18+')

    yellow = fields.Boolean('Yellow') 
    master = fields.Char(string="Master") 
    
    birth_date = fields.Date(string="DOB")
    age = fields.Integer(string="Age")
    
    fields_id = fields.Many2one(string="Fields")
    fieldmod_id = fields.Many2one(string="Fields Mod")
    
    template_id = fields.Many2one('stu.emp', string='Name Options')
    product_ids = fields.One2many(comodel_name='stu.emp', inverse_name='parent_id', string='Add Activities')
    
#     @api.onchange('birth_date')
#     def _onchange_birth_date(self):
#         
#         if self.birth_date:
#             d1 = datetime.strptime(self.birth_date, "%Y-%m-%d").date()
#             d2 = date.today()
#             self.age = relativedelta(d2, d1).years
# #             
#     @api.model
#     def update_ages(self):
#         
#         for rec in self.env['res.partner'].search([]):
#             if rec.birth_date:
#                 d1 = datetime.strptime(rec.birth_date, "%Y-%m-%d").date()
#                 d2 = date.today()
#                 rec.age = relativedelta(d2, d1).years
    
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')] , string="Gender")
    age_gender = fields.Integer(String="Age")
    work_hrs = fields.Integer(String="Working Hours", compute="onchange_work_hr", store=True)
    salary = fields.Integer("Salary")
    
    @api.multi
    @api.depends('gender')
    def onchange_work_hr(self):
        if self.gender == 'male':
            self.age_gender = 18
            self.work_hrs = self.age_gender * 8 
        elif self.gender == 'female':
            self.age_gender = 24
            self.work_hrs = self.age_gender * 8
        else:
            self.age_gender = 25
            self.work_hrs = self.age_gender * 8  

            
class Stu(models.Model):
    _name = 'stu.emp'
    
    image = fields.Binary("Image", attachment=True, help="aaaaaga")
    name = fields.Char(string="Name", required=True)
    roll_number = fields.Integer(string="Roll No")
    note = fields.Char(string="Note")
    depart = fields.Char(string="Department")
    
    # personal information
    address = fields.Char(string="Address")
    phone = fields.Integer(string="Mobile")
    email = fields.Char(string="Email")
    alterph = fields.Integer(string="Alternate Mobile")
    dob = fields.Date(string="Date of birth")
    
    # other details
    school = fields.Char(string="School")
    language = fields.Char(string="Language")
    parent_number = fields.Char(string="Parent Mobile")
    local_g = fields.Char(string="Local Gaurd")
    notes = fields.Char(string="Notes")
    
    # academic information
    exp = fields.Integer(string="Expirence")
    field_work = fields.Char(string="Fields Worked")
    ach = fields.Char(string="Achivement")
    cu_salary = fields.Char(string="Current Salary")
    
    address_new = fields.Many2one('stu.emp', string="Address")
    
    mari = fields.Selection([('married', 'Married'), ('unmarried', 'Unmarried')], string="Maritial Status")
    
    # test
    blue = fields.Boolean('18+')
    
    parent_id = fields.Many2one(comodel_name='emp.emp', string="Parent")
    product_id = fields.Many2one(comodel_name='emp.emp', string="Product")
    lst_price = fields.Float("Sale Price")
    act_name = fields.Char("Activity")

    yellow = fields.Boolean('Yellow') 
    master = fields.Char(string="Master") 
    
    birth_date = fields.Date(string="DOB")
    age = fields.Integer(string="Age")
    
    # new task
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')], string="Gender")
    
    @api.onchange('birth_date')
    def _onchange_birth_date(self):
        
        if self.birth_date:
            d1 = datetime.strptime(self.birth_date, "%Y-%m-%d").date()
            d2 = date.today()
            self.age = relativedelta(d2, d1).years
            
    @api.model
    def update_ages(self):
        
        for rec in self.env['res.partner'].search([]):
            if rec.birth_date:
                d1 = datetime.strptime(rec.birth_date, "%Y-%m-%d").date()
                d2 = date.today()
                rec.age = relativedelta(d2, d1).years


class Func(models.Model):
    _name = 'func.emp'
    
    name = fields.Many2one('emp.emp' , String="Name") 
    salary = fields.Integer(String="Salary")
    birth_date = fields.Date(string="DOB")
    age = fields.Integer(string="Age", compute="_calculate_age", store=True)
    
    @api.multi
    @api.onchange('name')
    def onchange_salary(self):
        if self.name:
            self.salary = self.name.work_hrs * 12 

    @api.multi
    def action_calculate_age(self):
        if self.birth_date:
            d1 = datetime.strptime(self.birth_date, "%Y-%m-%d").date()
            d2 = date.today()
            self.age = relativedelta(d2, d1).years
            
