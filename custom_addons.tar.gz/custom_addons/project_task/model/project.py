class CustomProjectWork(osv.osv):
    _name = "project.task.work"
    _inherit = "project.task.work"
    
#     user_ids = fields.many2many('res.users', 'task_user_rel', 'user_id', 'id', 'Assigned to', select=True, track_visibility='onchange')