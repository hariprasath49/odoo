# -*- encoding: utf-8 -*-
from odoo import models, fields, api

class purchase_order_po(models.Model):
    _inherit = 'purchase.order'
    
    pass_order_ids = fields.Many2one('project.task',string='Order Pass Id')
    company_id = fields.Many2one('res.company', string='Company')
    
    @api.model
    def report_purchase_order(self, docids, data=None):
        report_obj = self.env['report']
        report =  report_obj._get_report_from_name('construction.construction_report_purchase')
         
        return self.env['report'].get_action(self, 'construction.construction_report_purchase')

class product_product(models.Model):
    _inherit = 'product.product'

    product_qty = fields.Float(string='Qty')
    date_order_new = fields.Date(string='Date Order')
    date_planned_tack = fields.Date(string='Date Planned')
    description_product = fields.Char(string="description_product")
    
class project_task_work(models.Model):
    _inherit = 'project.task'
    
    user_ids = fields.Many2many('res.users', 'task_user_rel', 'user_id', 'id',string='Assigned to', 
                                select=True,track_visibility='onchange')
    product_id = fields.Many2many('product.product', string='Product Name')
    date_order_new = fields.Date(string='Date Order')
    date_planned_tack = fields.Date(string='Date Planned')
    po_count= fields.Integer(compute='_display_count')
    
    @api.multi
    def product_to_po(self):
        
        for rec in self.product_id:
            purchase_id = self.env['purchase.order'].create({
                                   'partner_id':rec.seller_ids[0].name.id,
                                   'date_order': rec.date_order_new,
                                   'date_planned': rec.date_planned_tack,
                                   'pass_order_ids': self.id,
                                   'order_line': [(0, 0, {'product_id':rec.id,
                                                          'name':rec.name,
                                                          'product_qty': rec.product_qty,
                                                          'product_uom': rec.uom_id.id,
                                                          'price_unit': rec.lst_price,
                                                          'date_order': rec.date_order_new,
                                                          'date_planned': rec.date_planned_tack,
                                                          })] 
                                    })
            print purchase_id
    
    @api.multi
    def action_related_po(self):
        count_id = self.env['purchase.order'].search([('pass_order_ids', '=', self.id)])
        self.ensure_one()
        action = self.env.ref('purchase.purchase_order_tree')
        print action
        
        return {
            'name': action.name,
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'views': [(action.id, 'tree')],
            'target': 'current',
            'res_model': 'purchase.order',
            'domain': [('pass_order_ids', '=', self.id)],
        }


    @api.one   
    def _display_count(self):   
        for rel in self:   
            count_id = self.env['purchase.order'].search([('pass_order_ids', '=', rel.id)])   
            self.po_count = len(count_id)
    
    @api.multi
    def action_view_related_products(self):
        ids = [line.product_id.id 
               for line in self.env['purchase.order'].search([('pass_order_ids', '=', self.id)])]
        return{
            'name'          :   ('View Chosen Products'),
            'type'          :   'ir.actions.act_window',
            'view_type'     :   'form',
            'view_mode'     :   'tree',
            'res_model'     :   'product.order',
            'target'        :   'new',
            'view_id'       :   False,
            'domain'        :   [('pass_order_ids', '=', self.id)], 
            }
    
    @api.model
    def report_project_task(self, docids, data=None):
        report_obj = self.env['report']
        report =  report_obj._get_report_from_name('construction.construction_report_order')
         
        return self.env['report'].get_action(self, 'construction.construction_report_order')
      
