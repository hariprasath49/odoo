# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Sale Order',
    'version' : '1.0',
    'summary': 'This is a employee module',
    'sequence': 1,
    'description': """to view emp details""",
    'category': 'other',
    'website': 'https://www.ppts.com',
    'depends' : ['base','sale','report'],
    'data': [
        'data/ir_sequence_datanum.xml',
        'views/sale_order.xml',
        'views/sale_config.xml',
        'data/mail_template.xml',
        'data/report_template.xml',
        
    ],
    'installable': True,
    'application': True,
}
