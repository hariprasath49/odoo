from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
from docutils.nodes import line

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    remain_quant = fields.Integer(string="Remaining Quantity")
    ticket_number_line = fields.Integer(string="Ticket")
    
#     @api.onchange('product_uom_qty','product_id')
#     def onchange_quant(self):
#          
#         for rec in self:
#             print rec.name,'1'
#             quant_sr = self.env["stock.quant"].search([('product_id', '=', rec.product_id.id)])
#             print len(quant_sr),'-0----'
#             qty = 0.0
#                  
#             for quant in quant_sr:
#                 qty += quant.qty
#                 print qty,'2'
#                 print quant.name
#                 remain_quant = quant
                
    @api.onchange('product_uom_qty', 'product_id')
    def onchange_quant(self):
        self.remain_quant = self.product_id.qty_available - self.product_uom_qty
        self.ticket_number_line =self.product_id.ticket_number
        print self.ticket_number_line
        


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    ticket = fields.Text(string="Ticket", readonly=True, required=True, copy=False, default='New')
    ticket_val = fields.Char(string="Value")
    type = fields.Selection([ ('rental', 'Rental'),('normal', 'Normal'),],'Type', default='normal')
    
    
    @api.model
    def report_sale_order(self, docids, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('sale_order.report_saleorder')
         
        return self.env['report'].get_action(self, 'sale_order.report_saleorder')
    
    @api.multi
    def cron_send_mail(self):
        res = {}
        res['alert_expiredate'] = self.env['ir.values'].get_default('sale.config.settings', 'alert_expiredate')
        print res['alert_expiredate']
        if res['alert_expiredate'] == True:
            current_date = str(datetime.now().date())
            order_ids = self.env['sale.order'].search([('validity_date', '>=', current_date)])
            for order in order_ids:
                order.send_mail_template()
    
#     @api.model
#     def create(self, vals):
#         result = super(SaleOrder, self).create(vals)
#         
# #         else:
# #             vals['ticket'] = self.env['ir.sequence'].next_by_code('sale.order') or 'New'
# #         if vals.get('ticket'):
# #             if 'company_id' in vals:
# #                 vals['ticket'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code('sale.order') or _('New')
# #             else:
# #                 vals['ticket'] = self.env['ir.sequence'].next_by_code('sale.order') or 'New'
#                 
#         product_id_sale_action_new = self.env['product.product'].search([])
#         print product_id_sale_action_new
#  
#         ctx = dict(self.env.context or {})
#         list_action_new = []
#         print list_action_new
#         for action_new in product_id_sale_action_new:
#             list_action_new.append(action_new)
#         print list_action_new 
#              
#         ctx.update({
#             'sale_action_new': list_action_new,
#             })    
#         print ctx
# #         template = self.env.ref('sale_order.email_template_create_sale')
# #         template.with_context(ctx).send_mail(self.id)
#         res = {}
#         res['create_order'] = self.env['ir.values'].get_default('sale.config.settings', 'create_order')
#         print res['create_order']
#         if res['create_order'] == True:
#             template = self.env.ref('sale_order.email_template_create_sale')
#             template.with_context(ctx).send_mail(self.id) 
#         
#         return result
    
    @api.multi
    def action_confirm(self): 
        result = super(SaleOrder, self).action_confirm()
        
        len_count = []
        ticket_list = []
        tickets = ""
        print line
        
        summ = 0
        for record in self.order_line:
            print 'commission'
            summ += record.product_id.ticket_number
        self.ticket_val = summ
        
        
        count = summ
        for i in range(count):
            x = self.env['ir.sequence'].next_by_code('sale.order')
            if not len(len_count) == 5:
                if not tickets:
                    tickets = x 
                else:
                    tickets = tickets + ',' + x
        print tickets
        print 'abc'
        
        
        ticket_list.append(str(tickets))
        
        self.ticket = ','.join(map(str, ticket_list))
         
        print ticket_list
        ctx = dict(self.env.context or {})
        ctx.update({
            'sale_action_new': ticket_list,
            })    
        print ctx
        
        template = self.env.ref('sale_order.email_template_ticket')
        template.with_context(ctx).send_mail(self.id)
        
#         self.env['ir.values'].create_order = True




#         product_id_sale_action_new = self.env['product.product'].search([])
#         print product_id_sale_action_new
#   
#         ctx = dict(self.env.context or {})
#         list_action_new = []
#            
#         for action_new in product_id_sale_action_new:
#             list_action_new.append(action_new)
#               
#         ctx.update({
#             'sale_action_new': list_action_new,
#             })    
#         print ctx
#          
#         res = {}
#         res['confirm_order'] = self.env['ir.values'].get_default('sale.config.settings', 'confirm_order')
#         print res['confirm_order']
#         if res['confirm_order'] == True:
#             template = self.env.ref('sale_order.email_template_create_sale')
#             template.with_context(ctx).send_mail(self.id) 
#         else:
#              raise Warning("Notification disabled" )
          
        return result
    
    @api.multi
    @api.depends('order_line.product_id')
    def send_mail_template(self):
        date = datetime.now().date()
        current_date = datetime.strftime(date, "%Y-%m-%d %H:%M:%S")
        product_sale_order = self.search([('date_order', '<=', current_date)])
        
        product_id_sale = self.env['sale.order.line'].search([('order_id', '=', self.id)])
        print product_id_sale

        ctx = dict(self.env.context or {})
        list = []
        for record in product_sale_order:
            list.append(record)

        list_new = []
        for rec in product_id_sale:
            list_new.append(rec)
            print rec.product_id.name
        print list_new
        
        ctx.update({
            'sale_records': list,
            'product_record': list_new,
            })    
        print ctx
        
        template = self.env.ref('sale_order.saleorder_mail_template')
        template.with_context(ctx).send_mail(self.id)  
        return True
    
    @api.multi
    def action_quotation_send(self):
        
        product_id_sale_action = self.env['product.product'].search([])
        print product_id_sale_action

        ctx = dict(self.env.context or {})
        list_action = []
         
        for action in product_id_sale_action:
            list_action.append(action)
            
        ctx.update({
            'sale_action': list_action,
            })    
        print ctx
         
        template = self.env.ref('sale.email_template_edi_sale')
        template.with_context(ctx).send_mail(self.id)  
        return True

    

class CustomSettings(models.TransientModel):
    _inherit = 'sale.config.settings'
    
    create_order = fields.Boolean(string='Create SaleOrder', help='Create Sale order to Send Email')
    confirm_order = fields.Boolean(string='Confirm SaleOrder')
    alert_expiredate = fields.Boolean(string='Alert ExpireDate')
    
#     @api.model
#     def get_default_params(self, fields):
#         res = {}
#         res['create_order'] = self.env['ir.values'].get_default('sale.config.settings', 'create_order')
# #         res['create_order'] = self.env['ir.values'].get_default('sale.value', 'create_order')
#         return res
#       
#     @api.multi
#     def set_my_category_defaults(self):
#         return self.env['ir.values'].sudo().set_default('sale.config.settings', 'create_order', self.create_order)
    
#     @api.model
#     def get_default_sale_values(self, fields):
#         sale_settings = self.env.user.company_id
#         sale_settings =self.env[('ir.values')]
#         return {
#             'create_order': sale.value,
#         }
    
#     @api.one
#     def set_sale_values(self):
#         sale_settings = self.env.user.company_id
#         sale_settings =self.get[('ir.values')]
#         sale.value = self.create_order

#     @api.multi
#     def settings_sale(self, cr, uid, ids):
#         sale_obj = self.pool.get('sale.config.settings')
#         sale_settings_value = sale_obj.browse(cr, uid, ids)[0]
#         value = sale_settings_value.confirm_order
#         return value


class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    ticket_number = fields.Integer('Ticket')
