# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Contract Create',
    'version': '1',
    'category': 'Sample Contract Create',
    'sequence': 1,
    'summary': 'Extend program',
    'description': """""",
    'website': 'https://www.odoo.com/page/',
    'depends': ['sale'],
    'data': [
        'views/sale_inherit.xml',
        'views/contract.xml',
                
            ],
   'installable': True,
   'application': True,
  
}
