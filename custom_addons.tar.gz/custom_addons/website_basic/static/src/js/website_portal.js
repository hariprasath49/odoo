
odoo.define('website_basic', function(require) {
    'use strict';
    require('website.website');

    if(!$('.o_website_basic_details').length) {
        return $.Deferred().reject("DOM doesn't contain '.o_website_portal_details'");
    }

    var state_options = $("select[name='state_id']:enabled option:not(:first)");
    $('.o_website_portal_details').on('change', "select[name='country_id']", function () {
        var select = $("select[name='state_id']");
        state_options.detach();
        var displayed_state = state_options.filter("[data-country_id="+($(this).val() || 0)+"]");
        var nb = displayed_state.appendTo(select).show().size();
        select.parent().toggle(nb>=1);
    });
    $('.o_website_portal_details').find("select[name='country_id']").change();
});


$('#name').keypress(function (e) {
    var regex = new RegExp(/^[a-zA-Z\s]+$/);
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    else {
        e.preventDefault();
        return false;
    }
});