from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
from docutils.nodes import line

class CRM_Lead(models.Model):
    _inherit = 'crm.lead'
    
    partner_id = fields.Many2one('res.partner', string="Customer")