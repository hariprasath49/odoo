# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Event process',
    'version': '1',
    'category': 'Sample',
    'sequence': 1,
    'summary': 'Event program',
    'description': """""",
    'website': 'https://www.odoo.com/page/employees',
    'depends': ['base'],
    'data': [
        'views/events.xml',
        'views/events1.xml',
            ],
   'installable': True,
   'application': True,
    
}
