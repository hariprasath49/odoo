from odoo import models, fields, api, _
from datetime import datetime
from dateutil.relativedelta import relativedelta


class ContractCreateLine(models.Model):
    _name = 'contract.create.line'
    
    
    line_id = fields.Many2one('contract.create', string='Order')
    product_id = fields.Many2one('product.product', string='Product')
    product_uom_qty = fields.Float(string='Product Quantity')
    price = fields.Float(string='Price')
    sub_total=fields.Float(string='Sub Total')
    
    

class ContractCreate(models.Model):
    _name = 'contract.create'
    

    customer_name=fields.Many2one('res.partner','Customer')
    date_contract= fields.Date(string="Date of Contract")
    order_lines = fields.One2many('contract.create.line', 'line_id', string='Contract Order Lines')
    view_contract=fields.Float(string='View Contract')
    
class WizardContract(models.TransientModel):
    """
    Account Bank Statement wizard that check that closing balance is correct.
    """
    _name = 'contract.wizard'
    
    contract_customer=fields.Char(String='Customer Name')
    datefrom = fields.Date(string="Date From")
    dateto = fields.Date(string="Date To")
    
    
    def validate(self):
        print 'test'
        
 
class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    @api.multi
    def create_contract(self):
        res = self.order_line
        lines = []
        for line in res:
            print line.product_id.name
            lines.append((0,0, {
                    'product_id':line.product_id.id,
                    'product_uom_qty':line.product_uom_qty,
                    'price':line.price_unit,
                    'sub_total':line.price_subtotal,
                    }))
        contract_id = self.env['contract.create'].create({
            'customer_name': self.partner_id.id,
            'date_contract': fields.Datetime.now(),
            'order_lines':lines,
            })
        