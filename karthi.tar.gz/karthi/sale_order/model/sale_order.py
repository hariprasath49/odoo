# -*- encoding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime

class res_partner(models.Model):
    _inherit = 'sale.order'
    
    @api.model
    def report_sale_order(self, docids, data=None):
        report_obj = self.env['report']
        report =  report_obj._get_report_from_name('sale_order.report_saleorder')
         
        return self.env['report'].get_action(self, 'sale_order.report_saleorder')
      
    
    
    @api.multi
    def cron_send_mail(self):
        order_ids = self.env['sale.order'].search([])
        for order in order_ids:
            order.send_mail_template()
    
    @api.multi
    @api.depends('order_line.product_id')
    def send_mail_template(self):
        date = datetime.now().date()
        current_date = datetime.strftime(date, "%Y-%m-%d %H:%M:%S")
        product_sale_order = self.search([('date_order','<=',current_date)])
        
        product_id_sale = self.env['sale.order.line'].search([('order_id', '=', self.id)])
        print product_id_sale

        ctx=dict(self.env.context or {})
        list=[]
        for record in product_sale_order:
            list.append(record)

        list_new=[]
        for rec in product_id_sale:
            list_new.append(rec)
            print rec.product_id.name
        print list_new
        
        ctx.update({
            'sale_records': list,
            'product_record': list_new,
            })    
        print ctx
        
        template = self.env.ref('sale_order.saleorder_mail_template')
        template.with_context(ctx).send_mail(self.id)  
        return True
    
    @api.multi
    def action_quotation_send(self):
        
        
        product_id_sale_action = self.env['product.product'].search([])
        print product_id_sale_action

        ctx=dict(self.env.context or {})
        list_action=[]
         
        for action in product_id_sale_action:
            list_action.append(action)
            
            
        ctx.update({
            'sale_action': list_action,
            })    
        print ctx
         
        template = self.env.ref('sale.email_template_edi_sale')
        template.with_context(ctx).send_mail(self.id)  
        return True
    
class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    remain_quant = fields.Integer(string="Remaining Quantity")
    
#     @api.onchange('product_uom_qty','product_id')
#     def onchange_quant(self):
#          
#         for rec in self:
#             print rec.name,'1'
#             quant_sr = self.env["stock.quant"].search([('product_id', '=', rec.product_id.id)])
#             print len(quant_sr),'-0----'
#             qty = 0.0
#                  
#             for quant in quant_sr:
#                 qty += quant.qty
#                 print qty,'2'
#                 print quant.name
#                 remain_quant = quant
                
    @api.onchange('product_uom_qty','product_id')
    def onchange_quant(self):
        self.remain_quant = self.product_id.qty_available - self.product_uom_qty
        
