# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Employee details',
    'version' : '1.0',
    'summary': 'This is a employee module',
    'sequence': 1,
    'description': """to view emp details""",
    'category': 'other',
    'website': 'https://www.ppts.com',
    'depends' : ['base'],
    'data': [
        'views/emp.xml',
        'views/func.xml'     
    ],
    'installable': True,
    'application': True,
}
