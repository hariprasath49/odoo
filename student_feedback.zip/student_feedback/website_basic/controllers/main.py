from odoo import http, tools, _
from odoo.http import request
import logging
_logger = logging.getLogger(__name__)


class WebsiteBasicForm(http.Controller):
#     partner_name = request.env['res.partner'].sudo().search([])
    
    
#     @http.route('/test_page2/', type='http',auth="public", website=True)
#     def website_basic_form2(self, **post):
#         print post
#         return request.render("website_basic.basic_template2")

    @http.route('/test_page/', type='http',auth="public", website=True)
    def website_basic_form(self, **post):
        print post
        lead = None
#         if post:
        lead = request.env['student.detail'].create({
            'name':post.get('name'),
            'request':post.get('request'),
            })
        print lead
#         lead[country_id]=countries 
        print post.get('name')
        
#         return request.redirect('/test_page2/',lead)
        return request.render("website_basic.basic_template2")
    
    
    
    
    
    
    
    
    