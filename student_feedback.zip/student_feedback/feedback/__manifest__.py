# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Feedback',
    'version' : '1.0',
    'summary': 'Student Feed back',
    'sequence': 1,
    'description': """to view student details""",
    'category': 'other',
    'website': 'https://www.non.com',
    'depends' : ['base','sale'],
    'data': [
        'views/feedback.xml',
        'data/mail_template.xml',
    ],
    'installable': True,
    'application': True,
}
