from odoo import api, fields, models, _
from datetime import date, datetime
from dateutil.relativedelta import relativedelta


class StudentDetail(models.Model):
    _name = 'student.detail'
    
    state = fields.Selection([
            ('pending', 'Pending'),
            ('accepted', 'Accepted'),
            ('rejected', 'Rejected'),
            ], default='pending')
    
    name = fields.Char(string="Name")
    request = fields.Html(string="Request")
    
    
    @api.one
    def approve(self):
        
        self.write({
            'state': 'accepted'
    })
        template = self.env.ref('feedback.email_template_feedback_accepted')
        template.send_mail(self.id, force_send=True)
    
    @api.one
    def reject(self):
        
        self.write({
            'state': 'rejected'
    })
    